<!DOCTYPE html>
<html>

<head>
    <title>Employee Name Search</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        .container {
            width: 50%;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius:
                10px;
            background: #f9f9f9;
        }

        input,
        button {
            padding: 10px;
            margin-top: 10px;
        }

        .result {
            margin-top: 15px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Employee Search</h2>
        <form method="POST">
            <input type="text" name="search_name" placeholder="Enter Employee Name" required>
            <button type="submit">Search</button>
        </form>
        <?php
 // Indexed array of 20 employee names
 $employees = [
 "John Doe", "Jane Smith", "Alice Johnson", "Robert Brown", "Emily Davis",
 "Michael Wilson", "Sarah Martinez", "James Anderson", "David White", "Laura Harris",
 "Daniel Clark", "Sophia Lewis", "Matthew Walker", "Olivia Young", "Ethan Hall",
 "Ava Allen", "Benjamin Wright", "Charlotte Scott", "Lucas Adams", "Mia Nelson"
 ];
 // Check if the form is submitted
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $search_name = trim($_POST["search_name"]);
 if (in_array($search_name, $employees)) {
 echo "<p class='result' style='color: green;'>$search_name exists in the employee list.</p>";
 } else {
 echo "<p class='result' style='color: red;'>$search_name not found in the employee
list.</p>";
 }
 }
 ?>
    </div>
</body>

</html>