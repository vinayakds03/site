<?php
session_start();
include "db.php";

$username = $_POST['username'];
$password = $_POST['password']; // using MD5 just for demo, use password_hash() in real apps


$sql = "SELECT * FROM cookie WHERE username='$username' AND password='$password'";

$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $_SESSION['username'] = $username;

    // If "Remember Me" is checked
    if (isset($_POST['remember'])) {
        setcookie("username", $username, time() + (86400 * 30), "/"); // 30 days
    }

    header("Location: welcome.php");
} else {
    echo "Invalid login credentials. <a href='index.html'>Try again</a>";
}
?>