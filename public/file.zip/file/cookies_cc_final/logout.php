<?php
session_start();
session_unset();
session_destroy();

// Remove the cookie
setcookie("username", "", time() - 3600, "/");

header("Location: index.html");
?>