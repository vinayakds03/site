const form = document.getElementById('rentalForm');

form.addEventListener('submit', function(e) {
  e.preventDefault();

  // Clear previous error messages
  document.querySelectorAll('.error').forEach(el => el.textContent = '');

  let isValid = true;

  // Name validation
  const name = form.name.value.trim();
  if (name.length < 2) {
    document.getElementById('nameError').textContent = 'Please enter a valid name.';
    isValid = false;
  }

  // Email validation
  const email = form.email.value.trim();
  if (!email.includes('@') || email.length < 5) {
    document.getElementById('emailError').textContent = 'Enter a valid email.';
    isValid = false;
  }

  // Phone validation
  const phone = form.phone.value.trim();
  if (!/^\d{10}$/.test(phone)) {
    document.getElementById('phoneError').textContent = 'Enter a valid 10-digit phone number.';
    isValid = false;
  }

  // Car selection validation
  const car = form.car.value;
  if (!car) {
    document.getElementById('carError').textContent = 'Please select a car.';
    isValid = false;
  }

  // Date validation
  const pickup = new Date(form.pickup.value);
  const returnDate = new Date(form.return.value);
  if (pickup >= returnDate) {
    document.getElementById('dateError').textContent = 'Return date must be after pickup date.';
    isValid = false;
  }

  if (isValid) {
    alert('Form submitted successfully!');
    form.reset();
  }
});
