<?php
include "db_conn.php";

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$department = $_POST['department'];

$sql = "INSERT INTO emp (name,email,phone,department) VALUES ('$name', '$email', '$phone', '$department')";

if($conn->query($sql)==TRUE){
    echo "employee registered successfully.<br><a href='view.php'>vieww all </a>";

}
else{
    echo"error";
}

$conn->close();
?>