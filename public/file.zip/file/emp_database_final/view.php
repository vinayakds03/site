<?php
include "db_conn.php";

$sql = "SELECT * FROM emp";
$result = $conn->query($sql);

echo "<h2>Registered employee</h2>"; // Missing semicolon fixed here
echo "<table border='1' cellpadding='10'>";

echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Department</th></tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['Sr.N0']}</td>
                <td>{$row['Name']}</td>
                <td>{$row['Email']}</td>
                <td>{$row['Phone']}</td>
                <td>{$row['Department']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No records found</td></tr>";
}
echo "</table>";
?>
