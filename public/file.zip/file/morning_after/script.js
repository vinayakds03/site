let userName = "";  // To store the name entered by the user

// Function to handle name submission
function submitName() {
  userName = document.getElementById('name-input').value;

  if (userName === "") {
    alert("Please enter your name.");
  } else {
    // Show lifetime and greeting after the user inputs their name
    displayLifetimeAndGreeting(userName);
  }
}

// Function to calculate lifetime weeks and greeting
function displayLifetimeAndGreeting(name) {
  // Calculate average number of weeks in a human lifetime
  const avgLifespanYears = 80;
  const weeksInYear = 52;
  const lifetimeWeeks = avgLifespanYears * weeksInYear;

  document.getElementById("lifetime").innerText =
    `On average, a human lives about ${lifetimeWeeks} weeks.`;

  // Tell the time of day
  const now = new Date();
  const hour = now.getHours();
  let timeOfDay = "";

  if (hour < 12) {
    timeOfDay = "morning";
  } else if (hour < 17) {
    timeOfDay = "afternoon";
  } else if (hour < 21) {
    timeOfDay = "evening";
  } else {
    timeOfDay = "night";
  }

  document.getElementById("greeting").innerText =
    `Good ${timeOfDay}, ${name}! The current time is ${now.toLocaleTimeString()}.`;
}

