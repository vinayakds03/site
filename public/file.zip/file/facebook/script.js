function validateForm() {
    let isValid = true;
  
    // Get all values
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const gender = document.getElementById('gender').value;
    const dob = document.getElementById('dob').value;
  
    // Clear previous errors
    document.querySelectorAll('.error').forEach(e => e.textContent = '');
  
    if (firstName === '') {
      document.getElementById('firstNameError').textContent = "First name is required";
      isValid = false;
    }
  
    if (lastName === '') {
      document.getElementById('lastNameError').textContent = "Last name is required";
      isValid = false;
    }
  
    if (email === '') {
      document.getElementById('emailError').textContent = "Email is required";
      isValid = false;
    } else if (!/^\S+@\S+\.\S+$/.test(email)) {
      document.getElementById('emailError').textContent = "Invalid email format";
      isValid = false;
    }
  
    if (password.length < 6) {
      document.getElementById('passwordError').textContent = "Password must be at least 6 characters";
      isValid = false;
    }
  
    if (confirmPassword !== password) {
      document.getElementById('confirmPasswordError').textContent = "Passwords do not match";
      isValid = false;
    }
  
    if (gender === '') {
      document.getElementById('genderError').textContent = "Please select a gender";
      isValid = false;
    }
  
    if (dob === '') {
      document.getElementById('dobError').textContent = "Date of birth is required";
      isValid = false;
    }
  
    return isValid;
  }
  