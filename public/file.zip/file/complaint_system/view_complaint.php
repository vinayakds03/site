<?php
include('db.php');

// Fetch complaints for a specific user (by name)
if (isset($_GET['user_name'])) {
    $user_name = $_GET['user_name'];
    $sql = "SELECT * FROM complaints WHERE user_name = '$user_name' ORDER BY created_at DESC";
    $result = $conn->query($sql);
} else {
    // Default: Fetch all complaints
    $sql = "SELECT * FROM complaints ORDER BY created_at DESC";
    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Complaints</title>
</head>
<body>
    <h2>Complaints Submitted</h2>

    <!-- Form to view complaints for a specific user -->
    <form action="view_complaints.php" method="get">
        <input type="text" name="user_name" placeholder="Enter your name to view your complaints" required>
        <button type="submit">View Complaints</button>
    </form>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>User Name</th>
                <th>Complaint</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['user_name']; ?></td>
                    <td><?php echo $row['complaint_text']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</body>
</html>

<?php $conn->close(); ?>

