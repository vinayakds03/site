<?php
include('db.php');

if($_SERVER['REQUEST_METHOD']== 'POST'){
    $user_name = $_POST['user_name'];
    $complaint_text = $_POST['complaint_text'];

    $sql = "INSERT INTO complaints (user_name, complaint_text) values ('$user_name','$complaint_text')";

    if($conn->query($sql)==TRUE){
        echo"complaint submitted successfully";

    }
    else{
        echo "error :" .$conn->error;

    }

    $conn->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Complaint</title>
</head>
<body>
    <h2>Submit Complaint</h2>
    <form action="submit_complaint.php" method="post">
        <input type="text" name="user_name" placeholder="Your Name" required><br><br>
        <textarea name="complaint_text" placeholder="Your Complaint" required></textarea><br><br>
        <button type="submit">Submit Complaint</button>
    </form>
    <a href="view_complaint.php">
    <button type="button">View Complaints</button>
</a>
    
</body>
</html>


