

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="form-container">
        <h2>Registration Form</h2>
        <form action="submit_form.php" method="post">
            <label for="name">Full name :</label>
            <input type="text" name="" id="name" required>

            <label for="email">Email :</label>
            <input type="email" name="" id="email" required>

            <button type="submit">submit</button>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>


