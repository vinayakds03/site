function validateForm(){
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const username = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value.trim();
    const confirmPass = document.getElementById('confirmPassword').value.trim();

if(
    firstName ===''|| lastName===''|| username===''||pass===''||confirmPass==='')
    {
        alert('please fill all fields')
    }

}

