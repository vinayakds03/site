<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>XML XSD Validator</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        textarea { width: 100%; height: 200px; }
        button { padding: 10px; margin-top: 10px; }
        .valid { color: green; font-weight: bold; }
        .invalid { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Validate XML Against XSD</h2>
    <form method="post">
        <textarea name="xmlInput" placeholder="Paste your XML here..."><?php echo htmlspecialchars($_POST['xmlInput'] ?? ''); ?></textarea><br>
        <button type="submit">Validate</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST['xmlInput'])) {
        $xsdFile = 'data.xsd'; // Ensure this path is correct

        $xmlContent = $_POST['xmlInput'];
        $dom = new DOMDocument();

        libxml_use_internal_errors(true);
        $dom->loadXML($xmlContent);

        if ($dom->schemaValidate($xsdFile)) {
            echo '<p class="valid">✅ XML is valid against the XSD.</p>';
        } else {
            echo '<p class="invalid">❌ XML is NOT valid:</p><ul class="invalid">';
            foreach (libxml_get_errors() as $error) {
                echo "<li>" . htmlspecialchars($error->message) . "</li>";
            }
            echo '</ul>';
            libxml_clear_errors();
        }
    }
    ?>
</body>
</html>
