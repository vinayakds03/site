function sayHello(){
    const name = document.getElementById('nameInput').value.trim();
    const output = document.getElementById('output');
    output.innerText = 'hello ,'+name;
}

const hoverButton = document.getElementById('   hoverButton');
hoverButton.addEventListener('mouseover',function(){
    hoverButton.style.backgroundColor='lightblue';
    hoverButton.innerText = 'Thanks for hovering';
});


hoverButton.addEventListener('mouseout',function(){
    hoverButton.style.backgroundColor='';
    hoverButton.innerText = 'Hover over me ';

});